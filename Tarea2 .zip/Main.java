/* 
Primer método: Retornar un mensaje que diga: "Programación Orientada a Objetos 2024".

Segundo método: Declarar una variable de tipo entero y asignarle un número X que represente la edad del estudiante. 
Retornar un mensaje dependiendo de esa variable si es mayor o igual a 21, el mensaje debe decir Mayor de edad,
de lo contrario Menor de edad.

Tercer método: Retornar el resultado de una Multiplicación de dos enteros que proporcionemos como parámetros.

Cuarto método:  Debe retornar una lista de numeros del 1 al X. Donde X es un parámetro de entrada del método a crear.
*/



public class Main {
    public static void main(String[] args) {
        String frase = metodoQueDevuelveFrase();
        System.out.println(frase);

        int edadEstudiante = 17; 

        String resultado = verificarEdad(edadEstudiante);
        System.out.println(resultado);
        
        int num1 = 4;
        int num2 = 2;
        
        int multiplicacion = Multi(num1, num2);
        System.out.println("El resultado de la multiplicación es: " + multiplicacion);
    
        
        int x = 10; 
        
        int[] numeros = generarArrayNumeros(x);

        System.out.println("Lista de números del 1 al " + x + ":");
        for (int numero : numeros) {
            System.out.print(numero + " ");
        }
    }

    public static String metodoQueDevuelveFrase() {
        return "Programación Orientada a Objetos 2024";
    }

    public static String verificarEdad(int edad) {
        if (edad >= 18) {
            return "Usted es mayor de edad";
        } else {
            return "Usted es menor de edad";
        }
    }
    
    public static int Multi(int a, int b) {
        return a * b;
    }
    
    public static int[] generarArrayNumeros(int x) {
        int[] arrayNumeros = new int[x];
        for (int i = 0; i < x; i++) {
            arrayNumeros[i] = i + 1;
        }
        return arrayNumeros;
    }
}
